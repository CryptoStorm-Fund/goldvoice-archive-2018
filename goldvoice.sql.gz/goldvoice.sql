-- Adminer 4.2.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `archives`;
CREATE TABLE `archives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time_start` int(11) NOT NULL,
  `time_end` int(11) NOT NULL,
  `block_start` int(11) NOT NULL,
  `block_end` int(11) NOT NULL,
  `finished` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `time_start_time_end` (`time_start`,`time_end`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `blocks`;
CREATE TABLE `blocks` (
  `id` bigint(20) unsigned NOT NULL,
  `time` int(11) NOT NULL,
  `witness` varchar(255) NOT NULL,
  `witness_user` int(11) NOT NULL,
  `witness_top` bit(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_witness_user` (`id`,`witness_user`),
  KEY `witness_user_id` (`witness_user`,`id`),
  KEY `witness_user` (`witness_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
/*!50100 PARTITION BY LINEAR KEY (`id`)
PARTITIONS 15 */;


DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `descr` varchar(255) NOT NULL,
  `posts` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name_status` (`name`(191),`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post` int(11) NOT NULL,
  `parent` int(11) NOT NULL,
  `author` int(11) NOT NULL,
  `permlink` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `delete_time` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `body` longtext NOT NULL,
  `json_metadata` blob NOT NULL,
  `pending_payout` varchar(50) NOT NULL,
  `payout` varchar(50) NOT NULL,
  `curator_payout` varchar(50) NOT NULL,
  `payout_max_gbg` tinyint(1) NOT NULL DEFAULT '1',
  `payout_percent_sg` int(11) NOT NULL DEFAULT '10000',
  `status` tinyint(1) NOT NULL,
  `payout_parse_time` int(11) NOT NULL,
  `payout_parse_priority` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post_parent_status` (`post`,`parent`,`status`),
  KEY `author_status` (`author`,`status`),
  KEY `post_sort_status` (`post`,`sort`,`status`),
  KEY `author_permlink` (`author`,`permlink`(191)),
  KEY `parent` (`parent`),
  KEY `payout_parse_priority_payout_parse_time_time_permlink_status` (`payout_parse_priority`,`payout_parse_time`,`time`,`permlink`(191),`status`),
  KEY `payout_parse_priority_payout_parse_time` (`payout_parse_priority`,`payout_parse_time`),
  KEY `time_payout_parse_priority_payout_parse_time` (`time`,`payout_parse_priority`,`payout_parse_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
/*!50100 PARTITION BY LINEAR KEY (`id`)
PARTITIONS 10 */;


DROP TABLE IF EXISTS `comments_history`;
CREATE TABLE `comments_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `body_old` blob NOT NULL,
  `patch` blob NOT NULL,
  `body_new` blob NOT NULL,
  `json_metadata` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comment` (`comment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `comments_tags`;
CREATE TABLE `comments_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` int(11) NOT NULL,
  `tag` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comment` (`comment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `comments_users`;
CREATE TABLE `comments_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comment` (`comment`),
  KEY `user_status` (`user`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `comments_votes`;
CREATE TABLE `comments_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` int(11) NOT NULL,
  `comment_author` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `comment_user` (`comment`,`user`),
  KEY `comment` (`comment`),
  KEY `comment_author_user` (`comment_author`,`user`),
  KEY `user_comment_author` (`user`,`comment_author`),
  KEY `user_time` (`user`,`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `currency_prices`;
CREATE TABLE `currency_prices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL,
  `currency` tinyint(3) NOT NULL,
  `price_btc` double NOT NULL,
  `price_usd` double NOT NULL,
  `price_rub` double NOT NULL,
  `price_gbg` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `currency_time` (`currency`,`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `errors`;
CREATE TABLE `errors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `block` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `data_name` varchar(255) NOT NULL,
  `data` blob NOT NULL,
  `sql` blob NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `feed`;
CREATE TABLE `feed` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `post` int(11) NOT NULL,
  PRIMARY KEY (`id`,`user`),
  KEY `user_post` (`user`,`post`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
/*!50100 PARTITION BY RANGE (`user`)
(PARTITION p1 VALUES LESS THAN (10000) ENGINE = InnoDB,
 PARTITION p2 VALUES LESS THAN (20000) ENGINE = InnoDB,
 PARTITION p3 VALUES LESS THAN (30000) ENGINE = InnoDB,
 PARTITION p4 VALUES LESS THAN (40000) ENGINE = InnoDB,
 PARTITION p5 VALUES LESS THAN (50000) ENGINE = InnoDB,
 PARTITION p6 VALUES LESS THAN (60000) ENGINE = InnoDB,
 PARTITION p7 VALUES LESS THAN (70000) ENGINE = InnoDB,
 PARTITION p8 VALUES LESS THAN (80000) ENGINE = InnoDB,
 PARTITION p9 VALUES LESS THAN (90000) ENGINE = InnoDB,
 PARTITION p10 VALUES LESS THAN (100000) ENGINE = InnoDB,
 PARTITION p11 VALUES LESS THAN (110000) ENGINE = InnoDB,
 PARTITION p12 VALUES LESS THAN (120000) ENGINE = InnoDB,
 PARTITION p13 VALUES LESS THAN (130000) ENGINE = InnoDB,
 PARTITION p14 VALUES LESS THAN (140000) ENGINE = InnoDB,
 PARTITION p15 VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;


DROP TABLE IF EXISTS `geolocation_name`;
CREATE TABLE `geolocation_name` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lat` decimal(10,8) NOT NULL,
  `lng` decimal(11,8) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lat_lng` (`lat`,`lng`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `branding` varchar(255) NOT NULL,
  `descr` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `url_status` (`url`(191),`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `group_feed`;
CREATE TABLE `group_feed` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group` int(11) NOT NULL,
  `post` int(11) NOT NULL,
  PRIMARY KEY (`id`,`group`),
  KEY `user_post` (`group`,`post`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
/*!50100 PARTITION BY LINEAR KEY (`group`)
PARTITIONS 100 */;


DROP TABLE IF EXISTS `group_members`;
CREATE TABLE `group_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group` int(11) NOT NULL,
  `member` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `del_time` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_status` (`member`,`status`),
  KEY `group` (`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `group_tags`;
CREATE TABLE `group_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group` int(11) NOT NULL,
  `tag_en` varchar(255) NOT NULL,
  `tag_name` varchar(255) NOT NULL,
  `tag_descr` varchar(255) NOT NULL,
  `tag_type` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_status_sort` (`group`,`status`,`sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `invite_struct`;
CREATE TABLE `invite_struct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `descr` text NOT NULL,
  `subscribes` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `public` tinyint(1) NOT NULL,
  `code` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `code_status_public` (`code`,`status`,`public`),
  KEY `user_status` (`user`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `languages`;
CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` int(11) NOT NULL,
  `code2` varchar(2) NOT NULL,
  `code3` varchar(3) NOT NULL,
  `name` varchar(80) NOT NULL,
  `name-ru` varchar(100) NOT NULL,
  `name-en` varchar(100) NOT NULL,
  `posts` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `localization` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code2_code3` (`code2`,`code3`),
  KEY `code2_status_posts` (`code2`,`status`,`posts`),
  KEY `code3_status_posts` (`code3`,`status`,`posts`),
  KEY `localization` (`localization`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `localization`;
CREATE TABLE `localization` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` int(11) NOT NULL,
  `cat` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lang_cat` (`lang`,`cat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `time` int(11) unsigned NOT NULL,
  `user` int(11) NOT NULL,
  `type` int(3) NOT NULL,
  `target` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`,`user`),
  KEY `user_type_status` (`user`,`type`,`status`),
  KEY `time_id` (`time`,`id`),
  KEY `user_status` (`user`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
/*!50100 PARTITION BY LINEAR KEY (`id`)
PARTITIONS 15 */;


DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL,
  `delete_time` int(11) NOT NULL,
  `parent_author` int(11) NOT NULL,
  `parent_permlink` varchar(255) NOT NULL,
  `parent_post` int(11) NOT NULL,
  `author` int(11) NOT NULL,
  `permlink` varchar(255) NOT NULL,
  `pending_payout` varchar(50) NOT NULL,
  `payout` varchar(50) NOT NULL,
  `curator_payout` varchar(50) NOT NULL,
  `cashout_time` int(11) NOT NULL,
  `max_accepted_payout` tinyint(1) NOT NULL DEFAULT '1',
  `percent_steem_dollars` int(11) NOT NULL DEFAULT '10000',
  `comments` int(11) NOT NULL,
  `upvotes` int(11) NOT NULL,
  `downvotes` int(11) NOT NULL,
  `adult` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `problem` tinyint(1) NOT NULL,
  `payout_parse_time` int(11) NOT NULL,
  `payout_parse_priority` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `author_permlink_status` (`author`,`permlink`(191),`status`),
  KEY `time` (`time`),
  KEY `parent_post` (`parent_post`),
  KEY `payout_parse_priority_payout_parse_time_time_status` (`payout_parse_priority`,`payout_parse_time`,`time`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
/*!50100 PARTITION BY LINEAR KEY (`id`)
PARTITIONS 10 */;


DROP TABLE IF EXISTS `posts_categories`;
CREATE TABLE `posts_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `posts_data`;
CREATE TABLE `posts_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `json_metadata` blob NOT NULL,
  `image` varchar(255) NOT NULL,
  `image_format` tinyint(3) NOT NULL,
  `app` varchar(255) NOT NULL,
  `format` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post` (`post`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `posts_history`;
CREATE TABLE `posts_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `body_old` blob NOT NULL,
  `patch` blob NOT NULL,
  `body_new` blob NOT NULL,
  `title` varchar(255) NOT NULL,
  `json_metadata` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post` (`post`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `posts_reblog_comment`;
CREATE TABLE `posts_reblog_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post` int(11) NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post` (`post`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `posts_tags`;
CREATE TABLE `posts_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post` int(11) NOT NULL,
  `tag` int(11) NOT NULL,
  `weight` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post` (`post`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `posts_users`;
CREATE TABLE `posts_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post` (`post`),
  KEY `user_status` (`user`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `posts_votes`;
CREATE TABLE `posts_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post` int(11) NOT NULL,
  `post_author` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_user` (`post`,`user`),
  KEY `post_author_user` (`post_author`,`user`),
  KEY `user_post_author` (`user`,`post_author`),
  KEY `post_weight` (`post`,`weight`),
  KEY `user_weight_time` (`user`,`weight`,`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `raw_operations`;
CREATE TABLE `raw_operations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `block` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `data` blob NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `operations_name` (`name`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
/*!50100 PARTITION BY LINEAR KEY (`id`)
PARTITIONS 10 */;


DROP TABLE IF EXISTS `reg_history`;
CREATE TABLE `reg_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `invite` int(11) NOT NULL,
  `public` tinyint(1) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status_login` (`status`,`login`(191)),
  KEY `time_status` (`time`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `reg_subscribes`;
CREATE TABLE `reg_subscribes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user1` int(11) NOT NULL,
  `invite` int(11) NOT NULL,
  `user2` int(11) NOT NULL,
  `subscribe_time` int(11) NOT NULL,
  `unsubscribe_time` int(11) NOT NULL,
  `amount` double NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `reg_transfers`;
CREATE TABLE `reg_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `amount` double NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_status_time` (`user`,`status`,`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `action_time` int(11) NOT NULL,
  `ip` varchar(39) NOT NULL,
  `key` varchar(20) NOT NULL,
  `cookie` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cookie_ip` (`cookie`,`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `tags`;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `en` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `ru` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `posts` int(11) NOT NULL,
  `comments` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `en` (`en`(191)),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `block` bigint(20) unsigned NOT NULL,
  `time` int(11) NOT NULL,
  `operations` blob NOT NULL,
  `parsed_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `block` (`block`),
  KEY `parsed_time_id` (`parsed_time`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `transfers`;
CREATE TABLE `transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL,
  `from` int(11) NOT NULL,
  `to` int(11) NOT NULL,
  `amount` decimal(11,3) NOT NULL,
  `currency` int(11) NOT NULL,
  `memo` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `from_to` (`from`,`to`),
  KEY `to_from` (`to`,`from`),
  KEY `to_currency_time` (`to`,`currency`,`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL,
  `login` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `telegram` varchar(255) NOT NULL,
  `avatar` text NOT NULL,
  `cover` text NOT NULL,
  `witnesses_proxy` varchar(255) NOT NULL,
  `creator` varchar(255) NOT NULL,
  `creator_fee` double NOT NULL,
  `reg_time` int(11) NOT NULL,
  `birthday` int(11) NOT NULL,
  `last_post_time` int(11) NOT NULL,
  `action_time` int(11) NOT NULL,
  `timezone` int(11) NOT NULL,
  `balance` double NOT NULL,
  `reg_balance` double NOT NULL,
  `sbd_balance` double NOT NULL,
  `vesting_shares` double NOT NULL,
  `savings_balance` double NOT NULL,
  `savings_sbd_balance` double NOT NULL,
  `voting_power` double NOT NULL,
  `reputation` bigint(20) NOT NULL,
  `reputation_short` mediumint(9) NOT NULL,
  `about` varchar(255) NOT NULL,
  `country` int(11) NOT NULL,
  `region` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `location` varchar(255) NOT NULL,
  `birth_location` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `background_color` varchar(6) NOT NULL,
  `ad_type` tinyint(3) NOT NULL,
  `ad_a_ads_id` int(11) NOT NULL,
  `ad_adsense_client` varchar(30) NOT NULL,
  `ad_adsense_slot` varchar(20) NOT NULL,
  `ad_ignore_cashout_time` tinyint(1) NOT NULL,
  `seo_show_comments` tinyint(1) NOT NULL,
  `seo_index_comments` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `bot` tinyint(1) NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `posts` int(11) NOT NULL,
  `reposts` int(11) NOT NULL,
  `comments` int(11) NOT NULL,
  `upvotes` int(11) NOT NULL,
  `downvotes` int(11) NOT NULL,
  `parse_time` int(11) NOT NULL,
  PRIMARY KEY (`login`),
  KEY `id_hide` (`id`,`status`),
  KEY `parse_priority_parse_time_status` (`parse_time`,`status`),
  KEY `status_parse_priority_parse_time` (`status`,`parse_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `users_links`;
CREATE TABLE `users_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_1` int(11) NOT NULL,
  `user_2` int(11) NOT NULL,
  `value` tinyint(1) NOT NULL,
  `mutually` tinyint(1) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_1_user_2` (`user_1`,`user_2`),
  KEY `user_1_value_mutually` (`user_1`,`value`,`mutually`),
  KEY `user_2_value_mutually` (`user_2`,`value`,`mutually`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `witnesses`;
CREATE TABLE `witnesses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `votes` bigint(20) NOT NULL,
  `total_missed` int(11) NOT NULL,
  `last_confirmed_block_num` int(11) NOT NULL,
  `signing_key` varchar(100) NOT NULL,
  `account_creation_fee` varchar(50) NOT NULL,
  `maximum_block_size` int(11) NOT NULL,
  `sbd_interest_rate` int(11) NOT NULL,
  `base` varchar(50) NOT NULL,
  `quote` varchar(50) NOT NULL,
  `last_sbd_exchange_update` int(11) NOT NULL,
  `running_version` varchar(255) NOT NULL,
  `parse_time` int(11) NOT NULL,
  `parse_priority` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user` (`user`),
  KEY `votes` (`votes`),
  KEY `parse_time_parse_priority` (`parse_time`,`parse_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `witnesses_polls`;
CREATE TABLE `witnesses_polls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `descr` text NOT NULL,
  `options` text NOT NULL,
  `user` int(11) NOT NULL,
  `start_time` int(11) NOT NULL,
  `end_time` int(11) NOT NULL,
  `start_block` int(11) NOT NULL,
  `end_block` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `url` (`url`),
  KEY `end_time` (`end_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `witnesses_votes`;
CREATE TABLE `witnesses_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `poll` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `start_votes` bigint(20) NOT NULL,
  `end_votes` bigint(20) NOT NULL,
  `option` int(11) NOT NULL,
  `block` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `option_start_votes_end_votes` (`option`,`start_votes`,`end_votes`),
  KEY `poll_time` (`poll`,`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 2018-09-28 07:23:30
